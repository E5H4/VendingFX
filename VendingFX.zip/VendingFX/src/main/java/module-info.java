module com.example.vendingfx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.vendingfx to javafx.fxml;
    exports com.example.vendingfx;
}